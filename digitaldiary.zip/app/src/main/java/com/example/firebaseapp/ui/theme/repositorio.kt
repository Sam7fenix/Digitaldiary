package com.example.firebaseapp.ui.theme

class DiaryRepository(private val diaryDao: DiaryDao) {
    val allEntries = diaryDao.getAllEntries()

    suspend fun insert(entry: DiaryEntry) {
        diaryDao.insert(entry)
    }
}
