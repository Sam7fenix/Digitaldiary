package com.example.firebaseapp

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.firebaseapp.ui.theme.DiaryAdapter
import com.example.firebaseapp.ui.theme.DiaryDatabase
import com.example.firebaseapp.ui.theme.DiaryEntry
import com.example.firebaseapp.ui.theme.DiaryRepository
import com.example.firebaseapp.ui.theme.DiaryViewModel
import com.example.firebaseapp.ui.theme.DiaryViewModelFactory
import com.example.firebaseapp.ui.theme.FirebaseappTheme
import com.google.android.material.floatingactionbutton.FloatingActionButton


//class MainActivity : AppCompatActivity() {
//    private val viewModel: DiaryViewModel by viewModels {
//        DiaryViewModelFactory(DiaryRepository(DiaryDatabase.getDatabase(this).diaryDao()))
//    }
//
//    @SuppressLint("MissingInflatedId")
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
//
//        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
//        val adapter = DiaryAdapter()
//        recyclerView.adapter = adapter
//        recyclerView.layoutManager = LinearLayoutManager(this)
//
//        viewModel.allEntries.observe(this) { entries ->
//            entries?.let { adapter.submitList(it) }
//        }
//
//        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener {
//            // Navegar para tela de adicionar/editar entrada
//        }
//    }
//}
//
//private fun DiaryAdapter.submitList(it: List<DiaryEntry>) {
//    TODO("Not yet implemented")
//}

class MainActivity : AppCompatActivity() {
    private val viewModel: DiaryViewModel by viewModels {
        DiaryViewModelFactory(DiaryRepository(DiaryDatabase.getDatabase(this).diaryDao()))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val adapter = DiaryAdapter()
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        viewModel.allEntries.observe(this) { entries ->
            entries?.let { adapter.submitList(it) }
        }

        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener {
            // Navigate to add/edit entry screen
        }
    }
}